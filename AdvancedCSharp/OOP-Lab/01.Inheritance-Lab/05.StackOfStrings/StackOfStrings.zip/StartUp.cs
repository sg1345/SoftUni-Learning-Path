﻿namespace CustomStack
{
    public class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
