﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NauticalCatchChallenge.Models
{
    public class FreeDiver : Diver
    {
        private const int _oxygenLevel = 120;
        public FreeDiver(string name) : base(name, _oxygenLevel)
        {
        }

        public override void Miss(int TimeToCatch)
        {
            OxygenLevel -= (int)Math.Round(TimeToCatch*0.6,0,MidpointRounding.AwayFromZero);
        }

        public override void RenewOxy()
        {
            OxygenLevel = _oxygenLevel;
        }
    }
}
