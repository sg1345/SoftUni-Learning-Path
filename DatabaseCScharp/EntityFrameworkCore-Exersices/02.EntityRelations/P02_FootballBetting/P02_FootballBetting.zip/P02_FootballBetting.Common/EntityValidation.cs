﻿namespace P02_FootballBetting.Common
{
    public static class EntityValidation
    {
    }
}
