﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=localhost\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True;Encrypt=False;";
    }
}
