﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=localhost\SQLEXPRESS;Database=Invoices;Integrated Security=True;Encrypt=False";
    }
}
