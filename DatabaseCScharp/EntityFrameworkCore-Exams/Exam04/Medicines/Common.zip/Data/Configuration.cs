﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=localhost\SQLEXPRESS;Database=Medicines_Exam04;Integrated Security=True;Encrypt=False";
    }
}
