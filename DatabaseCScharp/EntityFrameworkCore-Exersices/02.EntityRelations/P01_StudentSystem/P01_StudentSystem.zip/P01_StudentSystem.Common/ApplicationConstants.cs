﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P01_StudentSystem.Common
{
    public static class ApplicationConstants
    {
        public const string ConnectionString =
            @"Server=localhost\SQLEXPRESS;Database=StudentSystem;Trusted_Connection=True;Encrypt=False;";
    }
}