﻿namespace Medicines
{
    using AutoMapper;
    public class MedicinesProfile : Profile
    {
        // Configure your AutoMapper here if you wish to use it. If not, DO NOT DELETE OR RENAME THIS CLASS
        public MedicinesProfile()
        {
            
        }
    }
}
