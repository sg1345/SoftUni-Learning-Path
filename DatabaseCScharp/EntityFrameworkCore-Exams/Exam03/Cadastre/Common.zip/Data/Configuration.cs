﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=localhost\SQLEXPRESS;Database=Cadastre_Exam03;Integrated Security=True;Encrypt=False";
    }
}
