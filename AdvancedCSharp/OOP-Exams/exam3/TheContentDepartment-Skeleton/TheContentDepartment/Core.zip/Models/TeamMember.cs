﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TheContentDepartment.Models.Contracts;
using TheContentDepartment.Utilities.Messages;

namespace TheContentDepartment.Models
{
    public abstract class TeamMember : ITeamMember
    {
        private string _name;
        private List<string> _inProgress;

        public TeamMember(string name, string path)
        {
            _inProgress = new List<string>();
            Name = name;
            Path = path;
        }

        public string Name
        {
            get { return _name; }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException(ExceptionMessages.NameNullOrWhiteSpace);

                _name = value;
            }
        }

        public string Path { get; protected set; }

        public IReadOnlyCollection<string> InProgress => _inProgress.AsReadOnly();

        public void FinishTask(string resourceName)
        {
            _inProgress.Remove(resourceName);
        }

        public void WorkOnTask(string resourceName)
        {
            _inProgress.Add(resourceName);
        }
    }
}
