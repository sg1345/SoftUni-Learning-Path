﻿namespace AutomotiveRepairShop
{
    public class Vehicle
    {
        public Vehicle(string vin, int milaege, string damage)
        {
            this.VIN = vin;
            this.Мileage = milaege;
            this.Damage = damage;
        }

        public string VIN { get; set; }
        public int Мileage { get; set; }
        public string Damage { get; set; }

        public override string ToString()
        {
            return $"Damage: {this.Damage}, Vehicle: {this.VIN} ({this.Мileage} km)";
        }
    }
}
