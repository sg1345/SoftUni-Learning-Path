﻿namespace P02_FootballBetting.Common
{
    public static class ApplicationConstants
    {
        public const string ConnectionString =
            @"Server=localhost\SQLEXPRESS;Database=FootballBetting;Trusted_Connection=True;Encrypt=False;";
    }
}
